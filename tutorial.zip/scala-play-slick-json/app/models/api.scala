package models

import play.api.libs.json.Json

case class ProductsREST(id: Long, category_id: Long, name: String, description: String, price: Double)

object ProductsREST {
  implicit val productsFormat = Json.format[ProductsREST]
}