package models

import play.api.libs.json.Json

case class CategoriesREST(id: Long, name: String)

object CategoriesREST {
  implicit val categoriesFormat = Json.format[CategoriesREST]
}
