package models

import play.api.libs.json.Json

case class DeliveryREST(id: Long, name: String)

object DeliveryREST {
  implicit val deliveryFormat = Json.format[DeliveryREST]
}
