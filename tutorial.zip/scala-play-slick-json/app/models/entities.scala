package models

case class CategoriesEntity(id: Long, name: String)
case class DeliveryEntity(id: Long, name: String)
case class PaymentEntity(id: Long, name: String)
case class ProductsEntity(id: Long, category_id: Long, name: String, description: String, price: Double)









//case class Purchases(purId: Long, prodId: Long, userId: Long)

//case class Users(userId: Long, username: String)