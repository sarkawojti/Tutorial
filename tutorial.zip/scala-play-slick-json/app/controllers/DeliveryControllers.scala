package controllers

import javax.inject.Inject

import play.api.mvc.{Action, Controller}

import daos.DeliveryDAO
import play.api.libs.json.Json

/** https://stackoverflow.com/questions/32437585/cannot-find-an-implicit-executioncontext-error-in-scala-js-example-app **/
import play.api.libs.concurrent.Execution.Implicits.defaultContext

class DeliveryController @Inject() (deliveryDAO: DeliveryDAO) extends Controller {

  def deliveries = Action.async { implicit  request =>
    deliveryDAO.deliveries map {
      deliveries => Ok(Json.toJson(deliveries))
    }
  }
}
