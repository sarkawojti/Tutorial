package controllers

import javax.inject.Inject

import play.api.mvc.{Action, Controller}

import daos.CategoriesDAO
import play.api.libs.json.Json

/** https://stackoverflow.com/questions/32437585/cannot-find-an-implicit-executioncontext-error-in-scala-js-example-app **/
import play.api.libs.concurrent.Execution.Implicits.defaultContext

class CategoriesController @Inject() (categoriesDAO: CategoriesDAO) extends Controller {

  def categories = Action.async { implicit  request =>
    categoriesDAO.categories map {
      categories => Ok(Json.toJson(categories))
    }
  }
}
