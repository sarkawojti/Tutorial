package daos

import javax.inject.Inject

import models.{ProductsEntity, ProductsREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile

import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.{Future}

class ProductsDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Products = TableQuery[ProductsTable]

  def products(category_id : Long): Future[List[ProductsREST]] = {
    db.run(Products.filter(_.category_id === category_id).result).map(
      _.map {
        a => ProductsREST(id = a.id, category_id = a.category_id, name = a.name, description = a.description, price = a.price)
      }.toList)
  }

  class ProductsTable(tag: Tag) extends Table[ProductsEntity](tag, "products") {
    def id = column[Long]("id", O.AutoInc, O.AutoInc)
    def name = column[String]("name")
    def description = column[String]("description")
    def price = column[Double]("price")
    def category_id = column[Long]("category_id")
    def * = (id, category_id, name, description, price) <> (models.ProductsEntity.tupled, models.ProductsEntity.unapply)
  }
}
