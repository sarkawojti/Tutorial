package daos

import javax.inject.Inject



import models.{CategoriesEntity, CategoriesREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile

/** https://stackoverflow.com/questions/33304047/cannot-find-an-implicit-executioncontext-you-might-pass-spray-scala **/
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.{ Future }

class CategoriesDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Categories = TableQuery[CategoriesTable]

  def categories: Future[List[CategoriesREST]] = {
    db.run(Categories.result).map(
      _.map {
        a => CategoriesREST(id = a.id, name = a.name)
      }.toList)
  }

  class CategoriesTable(tag: Tag) extends Table[CategoriesEntity](tag, "categories") {
    def id = column[Long]("id", O.AutoInc, O.AutoInc)
    def name = column[String]("name")
    def * = (id, name) <> (models.CategoriesEntity.tupled, models.CategoriesEntity.unapply)
  }

}