package daos

import javax.inject.Inject



import models.{DeliveryEntity, DeliveryREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile

/** https://stackoverflow.com/questions/33304047/cannot-find-an-implicit-executioncontext-you-might-pass-spray-scala **/
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.{ Future }

class DeliveryDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Deliveries = TableQuery[DeliveryTable]

  def deliveries: Future[List[DeliveryREST]] = {
    db.run(Deliveries.result).map(
      _.map {
        a => DeliveryREST(id = a.id, name = a.name)
      }.toList)
  }

  class DeliveryTable(tag: Tag) extends Table[DeliveryEntity](tag, "deliveries") {
    def id = column[Long]("id", O.AutoInc, O.AutoInc)
    def name = column[String]("name")
    def * = (id, name) <> (models.DeliveryEntity.tupled, models.DeliveryEntity.unapply)
  }

}