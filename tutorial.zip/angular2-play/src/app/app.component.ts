import { Component, OnInit } from '@angular/core';
import { BasketService } from './basket/basket.service';
import { AuthService } from './auth/auth.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  constructor(private basket_service: BasketService, private auth_service: AuthService) {
    this.auth_service.handleAuthentication();
  }

  ngOnInit() {
    this.basket_service.clear();
  }

}
