import { Component, OnInit } from '@angular/core';
import {ProductService} from './product.service';
import {Product} from './product';
import {ActivatedRoute, Params} from "@angular/router";
import {BasketService} from './../basket/basket.service';
import 'rxjs/add/operator/switchMap';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  products: Product[];

  constructor(private productService: ProductService, private route: ActivatedRoute, private basket_service: BasketService) { }

  ngOnInit() {
    this.route.params.switchMap((params: Params) => this.productService.products(+params['id'])).subscribe(data => this.products = data);
  }

  add(product : Product) {
    this.basket_service.add(product);
  }

}
