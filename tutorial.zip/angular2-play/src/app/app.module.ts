import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule } from "@angular/router";

import { AppComponent } from './app.component';
import { CategoryComponent } from './category/category.component';
import { ProductComponent } from './product/product.component';
import { BasketComponent } from "./basket/basket.component";
import { BuyComponent } from "./buy/buy.component";

import { CategoryService } from "./category/category.service";
import { ProductService } from "./product/product.service";
import { BasketService } from "./basket/basket.service";
import { BuyService } from "./buy/buy.service";
import { AuthService } from "./auth/auth.service";

@NgModule({
  declarations: [
    AppComponent,
    CategoryComponent,
    ProductComponent,
    BasketComponent,
    BuyComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,

    ReactiveFormsModule,
    RouterModule.forRoot([
      { path: '.', component: AppComponent},
      { path: 'buy', component: BuyComponent},
      { path: 'category', component: CategoryComponent},
      { path: 'basket', component: BasketComponent},
      // https://stackoverflow.com/questions/42877193/error-cannot-match-any-routes-url-segment
      //{ path: 'product', component: ProductComponent },
      { path: 'product/:id', component: ProductComponent }

    ])
  ],
  providers: [
    CategoryService,
    ProductService,
    BasketService,
    BuyService,
    AuthService
  ],
  bootstrap: [
    AppComponent]
})
export class AppModule { }
