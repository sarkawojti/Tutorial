import { Component, OnInit} from '@angular/core';
import { Payment } from './payment';
import { Delivery } from './delivery';
import { BuyService } from './buy.service';

@Component({
  selector: 'buy',
  templateUrl: './buy.component.html',
  styleUrls: ['./buy.component.css']
})
export class BuyComponent implements OnInit {

  constructor(private buyService: BuyService) { }

  delivery : any = '';
  payment : any;

  payments: Payment[];
  deliveries: Delivery[];

  ngOnInit() {
    this.buyService.deliveries().subscribe(data => this.deliveries = data);
    this.buyService.payments().subscribe(data => this.payments = data);
  }


}
