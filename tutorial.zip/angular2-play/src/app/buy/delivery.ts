export class Delivery {
  id: number;
  name: string;
}
