export class Payment {
  id: number;
  name: string;
}
