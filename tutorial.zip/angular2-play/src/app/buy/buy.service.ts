import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import {Http, Headers, RequestOptions} from "@angular/http";
import {Payment} from "./payment";
import {Delivery} from "./delivery";

@Injectable()
export class BuyService {

  constructor(private http: Http) { }

  payments() {
    const headers: Headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');

    const options = new RequestOptions({headers: headers});

    return this.http.get('http://localhost:9000/payments', options)
      .map(response => <Payment[]>response.json());
  }

  deliveries() {
    const headers: Headers = new Headers();
    headers.append('Accept', 'application/json');
    headers.append('Content-Type', 'application/json');

    const options = new RequestOptions({headers: headers});

    return this.http.get('http://localhost:9000/deliveries', options)
      .map(response => <Delivery[]>response.json());
  }

}
