import { Component, OnInit} from '@angular/core';
import { Product } from "./../product/product";
import {BasketService} from "./basket.service";

@Component({
  selector: 'basket',
  templateUrl: './basket.component.html',
  styleUrls: ['./basket.component.css']
})
export class BasketComponent implements OnInit {
  basket: Product[];
  price: number;

  constructor(private basket_service: BasketService) { }

  remove(product : Product) {
    this.basket_service.remove(product);
    this.basket =  this.basket_service.basket();
    this.price = 0;
    for(var index in this.basket) { this.price += this.basket[index].price; }
  }

  ngOnInit() {
    this.basket =  this.basket_service.basket();
    this.price = 0;
    for(var index in this.basket) { this.price += this.basket[index].price; }
  }
}
