import { Injectable } from '@angular/core';
import {Product} from "./../product/product";
import 'rxjs/add/operator/map';

@Injectable()
export class BasketService {

  add(product : Product) {
    let basket_container = window.localStorage.getItem("Basket");

    let basket = new Array<Product>();
    if(basket_container != null) {
      basket = <Product[]>JSON.parse(basket_container);
    }

    basket.push({id: product.id, category_id: product.category_id, name: product.name, price: product.price, description: product.description});
    window.localStorage.setItem("Basket", JSON.stringify(basket));
  }

  clear(){
    let basket = new Array<Product>();
    window.localStorage.setItem("Basket", JSON.stringify(basket));
  }

  remove(product : Product){
    let basket_container = window.localStorage.getItem("Basket");
    let basket = <Product[]>JSON.parse(basket_container);
    basket.splice(basket.indexOf(product), 1);
    window.localStorage.setItem("Basket", JSON.stringify(basket));
  }

  basket(){
    let basket_container = window.localStorage.getItem("Basket");
    let basket = new Array<Product>();
    if(basket_container != null) {
      basket = <Product[]>JSON.parse(basket_container);
    }
    return basket;
  }
}
