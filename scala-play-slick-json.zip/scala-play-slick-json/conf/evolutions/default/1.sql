# --- !Ups

CREATE TABLE categories (
"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
"name" TEXT NOT NULL
);

CREATE TABLE payments (
"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
"name" TEXT NOT NULL
);

CREATE TABLE deliveries (
"id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
"name" TEXT NOT NULL
);


CREATE TABLE products (
 "id" INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
 "category_id" INTEGER NOT NULL,
 "name" TEXT  NOT NULL,
 "description" TEXT NOT NULL,
 "price" INTEGER NOT NULL
);

INSERT INTO deliveries (name) VALUES ('delivery way 1st');
INSERT INTO deliveries (name) VALUES ('delivery way 2nd');
INSERT INTO payments   (name) VALUES ('payment kind 1st');
INSERT INTO payments   (name) VALUES ('payment kind 2nd');
INSERT INTO payments   (name) VALUES ('payment kind 3rd');

INSERT INTO categories (name) VALUES ('1st Category');
INSERT INTO categories (name) VALUES ('2nd Category');
INSERT INTO categories (name) VALUES ('3rd Category');
INSERT INTO categories (name) VALUES ('4th Category');

INSERT INTO products (category_id, name, description, price) VALUES (0, '1st product', 'description 1st product', 4);
INSERT INTO products (category_id, name, description, price) VALUES (0, '2nd product', 'description 2nd product', 40);
INSERT INTO products (category_id, name, description, price) VALUES (1, '3rd product', 'description 3rd product', 14);
INSERT INTO products (category_id, name, description, price) VALUES (3, '4th product', 'description 4th product', 44);
INSERT INTO products (category_id, name, description, price) VALUES (3, '5th product', 'description 1st product', 4);
INSERT INTO products (category_id, name, description, price) VALUES (3, '6th product', 'description 2nd product', 400);
INSERT INTO products (category_id, name, description, price) VALUES (4, '7th product', 'description 3rd product', 141);
INSERT INTO products (category_id, name, description, price) VALUES (4, '8th product', 'description 4th product', 35);

# --- !Downs

DROP TABLE categories;
DROP TABLE payments;
DROP TABLE deliveries;
DROP TABLE products;
