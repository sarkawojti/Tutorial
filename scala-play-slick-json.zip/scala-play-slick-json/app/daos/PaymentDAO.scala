package daos

import javax.inject.Inject



import models.{PaymentEntity, PaymentREST}
import play.api.db.slick.{DatabaseConfigProvider, HasDatabaseConfigProvider}
import slick.driver.JdbcProfile

/** https://stackoverflow.com/questions/33304047/cannot-find-an-implicit-executioncontext-you-might-pass-spray-scala **/
import scala.concurrent.ExecutionContext.Implicits.global

import scala.concurrent.{ Future }

class PaymentDAO @Inject()(protected val dbConfigProvider: DatabaseConfigProvider)
  extends HasDatabaseConfigProvider[JdbcProfile] {

  import driver.api._

  val Payments = TableQuery[PaymentTable]

  def payments: Future[List[PaymentREST]] = {
    db.run(Payments.result).map(
      _.map {
        a => PaymentREST(id = a.id, name = a.name)
      }.toList)
  }

  class PaymentTable(tag: Tag) extends Table[PaymentEntity](tag, "payments") {
    def id = column[Long]("id", O.AutoInc, O.AutoInc)
    def name = column[String]("name")
    def * = (id, name) <> (models.PaymentEntity.tupled, models.PaymentEntity.unapply)
  }

}