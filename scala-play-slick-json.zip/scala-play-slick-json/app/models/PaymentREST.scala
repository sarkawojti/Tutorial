package models

import play.api.libs.json.Json

case class PaymentREST(id: Long, name: String)

object PaymentREST {
  implicit val paymentFormat = Json.format[PaymentREST]
}
