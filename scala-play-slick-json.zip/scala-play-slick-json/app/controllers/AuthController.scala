package controllers

import play.api.mvc._
import javax.inject.Inject

import play.api.libs.ws._
import play.api.libs.concurrent.Execution.Implicits.defaultContext
import play.api.libs.json.Json


class AuthController @Inject()() extends Controller {

  def auth = Action {
    redirect("https://www.facebook.com/dialog/oauth?client_id=477421982657199&redirect_uri=http://localhost:9000/auth&scope=email")
  }
}
