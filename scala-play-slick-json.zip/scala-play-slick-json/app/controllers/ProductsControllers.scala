package controllers

import javax.inject.Inject

import play.api.mvc.{Action, Controller}

import daos.ProductsDAO
import play.api.libs.json.Json

/** https://stackoverflow.com/questions/32437585/cannot-find-an-implicit-executioncontext-error-in-scala-js-example-app **/
import play.api.libs.concurrent.Execution.Implicits.defaultContext

class ProductsController @Inject() (productsDAO: ProductsDAO) extends Controller {

  def products(category_id: Long) = Action.async { implicit  request =>
    productsDAO.products(category_id) map {
      products => Ok(Json.toJson(products))
    }
  }
}
