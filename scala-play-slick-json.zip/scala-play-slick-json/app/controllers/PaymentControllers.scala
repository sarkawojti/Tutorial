package controllers

import javax.inject.Inject

import play.api.mvc.{Action, Controller}

import daos.PaymentDAO
import play.api.libs.json.Json

/** https://stackoverflow.com/questions/32437585/cannot-find-an-implicit-executioncontext-error-in-scala-js-example-app **/
import play.api.libs.concurrent.Execution.Implicits.defaultContext

class PaymentController @Inject() (paymentDAO: PaymentDAO) extends Controller {

  def payments = Action.async { implicit  request =>
    paymentDAO.payments map {
      payment => Ok(Json.toJson(payment))
    }
  }
}
