package controllers

import javax.inject.Inject

import play.api.libs.json.Json
import play.api.mvc._

class Application @Inject() () extends Controller {

  def index = Action { implicit  request =>
    Ok(Json.toJson("MUST BE"))}

}
